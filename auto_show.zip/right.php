<?php

include_once 'global.php';

$smarty->display("right.html");
?>