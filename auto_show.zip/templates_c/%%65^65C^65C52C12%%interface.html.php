<?php /* Smarty version 2.6.22, created on 2012-11-28 03:02:45
         compiled from interface.html */ ?>

<html>
<head>
<title>Insert title here</title>
<?php echo '
        <SCRIPT language=javascript>
function secBoard(n)
{
	alert(1);
}
              </SCRIPT>'; ?>

</head>
<body>

</body>
</html>