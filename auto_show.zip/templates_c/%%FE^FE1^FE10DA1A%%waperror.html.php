<?php /* Smarty version 2.6.22, created on 2013-04-03 14:24:34
         compiled from waperror.html */ ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="utf-8"<?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--STATUS OK-->
<head>
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
<meta http-equiv="Cache-control" content="no-cache" />

<title></title>
</head>
<body>
<div>
    <div>
    	<p><?php echo $this->_tpl_vars['error']; ?>
</p>
    	<P><a href="wapshow.php?qrcode=<?php echo $this->_tpl_vars['qrcode']; ?>
">返回</a></P>
    </div>
  <br/>
</div>
</body>
</html>