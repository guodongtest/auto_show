<?php /* Smarty version 2.6.22, created on 2012-11-29 17:36:28
         compiled from inface.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
<!--<?php echo '-->

<!--'; ?>
-->
</head>
<body>
<form action="../infce.php" name='form1' method="POST">
<input type="text" name="name" value="姓名"/>
<input type="text" name="pass" value="密码"/>
<input type="submit" value="提交"/> 
</form>
</body>
</html>