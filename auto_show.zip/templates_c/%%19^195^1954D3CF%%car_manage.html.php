<?php /* Smarty version 2.6.22, created on 2011-11-03 08:23:30
         compiled from ../templates/car_manage.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
    asdasdads
</body>
</html>