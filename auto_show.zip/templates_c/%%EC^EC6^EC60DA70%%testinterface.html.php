<?php /* Smarty version 2.6.22, created on 2012-11-28 02:44:35
         compiled from testinterface.html */ ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="UTF-8" <?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Insert title here</title>

<script type="javascript" src="./../test/files/jquery.min.js"></script>
<script type="javascript">
</script>
</head>
<body>
<p id="a">接口调试</p>
</body>
</html>