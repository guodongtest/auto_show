<?php
$server="localhost";
$database="auto_show";
$username="root";
$userpass="";
$encode="utf8";

$cache_dir="/cache/";
$config_dir="/config/";
$template_dir="/templates/";
$compile_dir="/templates_c/";
?>