<?php

$xml_data = '{"item1":{"item11":{"n":"chenling",
"m":"llll"},"sex":"男","age":"25"},"item2":
{"item21":"ling","sex":"女","age":"24"}}';

date_default_timezone_set('PRC');//设置默认时区为北京时间

//$json_data = '[{"name":"张国栋2","sex":"1","phone":"15210909358","email":"wwf0008@126.com","province":"河北","city":"保定",
//"is_havecar":"2","year":"","brand":"","models":"","driven_age":"1","plan_time":"1","plan_budget":"1","interest_car":"2013牧马人Sahara 两门款",
//"dealer":"保定天威","is_followup":"1","is_receive":"1","helper_id":"801","duty":"全新进口Jeep大切诺基SRT8","isqrcode":"0","savetime":"'.date('Y-m-d H:i:s').'"}]';

//,{"name":"张国栋","sex":"28","phone":"15210909358","email":"wwf0008@126.com","province":"河北","city":"保定",
//"is_havecar":"2","year":"","brand":"","models":"","driven_age":"1","plan_time":"1","plan_budget":"1","interest_car":"1",
//"dealer":"","is_followup":"1","is_receive":"1","helper_id":"801","duty":"全新进口Jeep大切诺基SRT8"},{}]';
//$json_data = '[]';

//$json_data = '[{"name":"张国栋2","sex":"28","phone":"15210909358","email":"wwf0008@126.com","province":"河北","city":"保定",
//"is_havecar":"2","year":"","brand":"","models":"","driven_age":"1","plan_time":"1","plan_budget":"1","interest_car":"2013牧马人Sahara 两门款",
//"dealer":"北京百盛","is_followup":"1","is_receive":"1","duty":"全新进口Jeep大切诺基SRT8","sell":"销售"}]';

//$json_data='[{"name":"zgd","sex":"1","phone":"18077656669","email":"","province":"特别行政区","city":"香港","is_havecar":"2","year":"","brand":"","models":"","driven_age":"","plan_time":"1","plan_budget":"","interest_car":"全新进口Jeep大切诺基5.7L","dealer":"  上海东联京沪汽车销售服务有限公司","is_followup":"0","is_receive":"0","helper_id":"803","duty":"D-SUV(KL)Limited","qrcode":"4","savetime":"2013/03/30 18:57:09"}
//,{"name":"zgd","sex":"1","phone":"18077656670","email":"","province":"特别行政区","city":"香港","is_havecar":"2","year":"","brand":"","models":"","driven_age":"","plan_time":"1","plan_budget":"","interest_car":"全新进口Jeep大切诺基5.7L","dealer":"  上海东联京沪汽车销售服务有限公司","is_followup":"0","is_receive":"0","helper_id":"803","duty":"D-SUV(KL)Limited","qrcode":"4","savetime":"2013/03/30 18:57:09"}
//,{"name":"zgd","sex":"1","phone":"18077656671","email":"","province":"特别行政区","city":"香港","is_havecar":"2","year":"","brand":"","models":"","driven_age":"","plan_time":"1","plan_budget":"","interest_car":"全新进口Jeep大切诺基5.7L","dealer":"  上海东联京沪汽车销售服务有限公司","is_followup":"0","is_receive":"0","helper_id":"803","duty":"D-SUV(KL)Limited","qrcode":"4","savetime":"2013/03/30 18:57:09"}
//,{"name":"zgd","sex":"1","phone":"18077656672","email":"","province":"特别行政区","city":"香港","is_havecar":"2","year":"","brand":"","models":"","driven_age":"","plan_time":"1","plan_budget":"","interest_car":"全新进口Jeep大切诺基5.7L","dealer":"  上海东联京沪汽车销售服务有限公司","is_followup":"0","is_receive":"0","helper_id":"803","duty":"D-SUV(KL)Limited","qrcode":"4","savetime":"2013/03/30 18:57:09"}]';

//$json_data='{"name":"","phone":"","sell":"销售1"}';

$json_data='[{"id":"3","name":"王","sex":"1","phone":"13717701223","email":"","interest_car":"2014 指南者2.4L 蛇年特别版","plan_time":"6","province":"北京","city":"东城","dealer":"北京中进百旺","sell":"销售1"},{"id":"4","name":"杨","sex":"1","phone":"13366016799","email":"","interest_car":"2014 指南者2.4L","plan_time":"8","province":"北京","city":"昌平","dealer":"北京中进百旺","sell":"销售1"},{"id":"5","name":"李村","sex":"1","phone":"13933801832","email":"","interest_car":"2014 大切诺基3.6L","plan_time":"6","province":"河北","city":"石家庄","dealer":"北京中进百旺","sell":"销售1"},{"id":"6","name":"李","sex":"1","phone":"15117954102","email":"","interest_car":"2013 牧马人Sahara 四门款","plan_time":"7","province":"北京","city":"海淀","dealer":"北京中进百旺","sell":"销售1"},{"id":"7","name":"张","sex":"2","phone":"15066108039","email":"","interest_car":"2014 指南者2.4L","plan_time":"7","province":"山东","city":"济南","dealer":"北京中进百旺","sell":"销售1"}]';

$url = "http://localhost//updcar.php";
//$url = "http://localhost//querycar.php";
$header[] = "Content-type: text/json";//定义content-type为json
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
$response = curl_exec($ch);
if(curl_errno($ch))
{
    print curl_error($ch)."<br/>";
}
curl_close($ch);
//$response=json_decode($response,true);
//var_dump($response); 
echo $response;

?>